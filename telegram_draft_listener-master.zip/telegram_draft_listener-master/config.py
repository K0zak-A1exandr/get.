api_id = 123456 #your api id
api_hash = "your api hash"
tlgraph_token = "your telegraph token"
name = "session name"
